window.addEventListener('DOMContentLoaded', () => {
  console.log("SmartSpoil GUI Deployer Ready");
});
