// github_upload_octokit.js
// Uploads files to a GitHub repository using @octokit/rest

const { Octokit } = require("@octokit/rest");
const fs = require("fs");
const path = require("path");

// CONFIG
const token = "YOUR_GITHUB_TOKEN";
const owner = "YOUR_GITHUB_USERNAME";
const repo = "YOUR_REPO_NAME";
const branch = "main"; // or 'master'
const localDir = "./upload"; // folder containing files to upload

const octokit = new Octokit({ auth: token });

async function uploadFile(filePath) {
  const content = fs.readFileSync(filePath, "base64");
  const filename = path.basename(filePath);

  await octokit.repos.createOrUpdateFileContents({
    owner,
    repo,
    path: filename,
    message: `Add ${filename}`,
    content,
    branch
  });
}

fs.readdirSync(localDir).forEach(file => {
  uploadFile(path.join(localDir, file))
    .then(() => console.log(`Uploaded ${file}`))
    .catch(err => console.error(`Failed to upload ${file}:`, err.message));
});
