#!/bin/bash
# github_upload_ghcli.sh
# Uploads files to GitHub using GitHub CLI

REPO="yourusername/your-repo"
BRANCH="main"
FOLDER="./upload"

gh repo clone $REPO temp-repo
cd temp-repo
cp -r $FOLDER/* .
git add .
git commit -m "Upload files"
git push origin $BRANCH
cd ..
rm -rf temp-repo
