# github_upload_pygithub.py
# Uploads files to GitHub using PyGitHub

from github import Github
import base64
import os

token = "YOUR_GITHUB_TOKEN"
repo_name = "YOUR_GITHUB_USERNAME/YOUR_REPO_NAME"
local_dir = "./upload"

g = Github(token)
repo = g.get_repo(repo_name)

for filename in os.listdir(local_dir):
    filepath = os.path.join(local_dir, filename)
    with open(filepath, "rb") as f:
        content = f.read()
    try:
        repo.create_file(filename, f"Add {filename}", content, branch="main")
        print(f"Uploaded {filename}")
    except Exception as e:
        print(f"Failed to upload {filename}: {e}")
